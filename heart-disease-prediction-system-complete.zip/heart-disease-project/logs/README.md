# Logs Directory

Application logs will be stored here:
- `backend.log` - Backend server logs
- `frontend.log` - Frontend development server logs
- `backend-error.log` - PM2 error logs
- `backend-out.log` - PM2 output logs
